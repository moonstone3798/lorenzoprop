<footer>
<div class="footer">
    <div class="dirección" > 
        <p id="letra">Suc. Caballito: Av Avellaneda 112</p>
        <P id="letra">Suc. Boedo: Av Boedo 1926</P>
    </div>
    <div class="telefono">
        <p id="letra" >4800-5484 </p>  
        <p id="letra" >  4600-1186 </p>
    </div>
    <br>
    <div class="mail" >
        <p id="letra">info@lorenzoprop.com</p>
    </div>
    
</div>
   </footer>
</body>
</html><?php /**PATH C:\Users\moons\OneDrive\Escritorio\arreglo\lorenzoprop\resources\views/layouts/footer.blade.php ENDPATH**/ ?>