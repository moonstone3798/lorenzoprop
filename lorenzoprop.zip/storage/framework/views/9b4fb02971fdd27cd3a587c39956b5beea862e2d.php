
<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
    <h1 style="text-align:center">Eliminar Venta</h1>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="background:rgba(255, 255, 255, 0.329); width:100%; ">
        

            <div class="col">
                <img src="/compras/<?php echo e($Compra->imagen); ?> " class="img-thumbnail" style="width:400px; height:350px; object-fit:cover; margin-left:33%">
            </div>
            
            <div class="col text-danger align-self-center">
            <form action="/eliminarVenta" method="post" style="text-align:center">
            <?php echo csrf_field(); ?>
            <?php echo method_field('delete'); ?>
            <label>   Id:  <?php echo e($Compra->id); ?> </label>
                <br><br>
                <label>   Dirección:  <?php echo e($Compra->dirección); ?> </label>
                <br><br>
                <label> Precio:  usd <?php echo e($Compra->precio); ?></label>
                <br><br>
                <label> Descripción:  <?php echo e($Compra->descripción); ?></label>
                <br><br><br>
                  

                <input type="hidden" name="id"
                       value="<?php echo e($Compra->id); ?>">
                <input type="hidden" name="dirección"
                       value="<?php echo e($Compra->dirección); ?>">
                <button class="btn btn-danger btn-block my-3">Confirmar baja</button>
                <button><a href="/adminVentas" class="btn btn-outline-secondary btn-block">
                    Volver a panel
                </a></button>

            </form>
            </div>
        

            <script>
                Swal.fire(
                    'Advertencia',
                    'Si pulsa el botón "Confirmar baja", se eliminará la propiedad seleccionada.',
                    'warning'
                )
            </script>


</div>
        </div>
    </div>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH C:\Users\moons\OneDrive\Escritorio\arreglo\lorenzoprop\resources\views/eliminarVenta.blade.php ENDPATH**/ ?>