
<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
    <h1 style="text-align:center">Agregar una nueva Venta</h1>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="background:rgba(255, 255, 255, 0.329); width:100%">
<?php if( $errors->any() ): ?>
            <div class="alert alert-danger col-8 mx-auto p-2"  style="background:rgba(240, 14, 38); width:30%; margin-bottom:18px; margin-top:-6px">
                <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li style="text-align:center; color:black; list-style=circle"><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
<div class="agregar">

            <form action="/agregarVenta" method="post">
            <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="dirección">Ingrese la Dirección </label>
                    <input type="text" name="dirección"
                           value="<?php echo e(old('dirección')); ?>"
                           class="form-control" id="dirección">
                           <br><br><br>
                           <label for="precio">Ingrese el Precio </label>
                    <input type="text" name="precio"
                           value="<?php echo e(old('precio')); ?>"
                           class="form-control" id="precio">
                           <br><br><br>
                           <label for="descripción">Ingrese la Descripción</label>
                           <br>
                           <textarea name="descripción" id="descripción" value="<?php echo e(old('descripción')); ?>" cols="30" rows="10" style="width: 50%"></textarea>
 
                  
                           <br><br><br>
<label for="imagen">Ingrese imagen</label>
<input type="file" name="imagen"  class="custom-file-input" id="customFileLang" lang="es">
<label class="custom-file-label" for="customFileLang" data-browse="Buscar en disco"> </label>                    

<br><br><br>
<label for="imagen2">Ingrese imagen </label>
<input type="file" name="imagen2"  class="custom-file-input" id="customFileLang" lang="es">
<label class="custom-file-label" for="customFileLang" data-browse="Buscar en disco"> </label>

<br><br><br>
<label for="imagen3">Ingrese imagen</label>
<input type="file" name="imagen3"  class="custom-file-input" id="customFileLang" lang="es">
<label class="custom-file-label" for="customFileLang" data-browse="Buscar en disco"> </label>
<br><br><br>
<label for="imagen4">Ingrese imagen</label>
<input type="file" name="imagen4"  class="custom-file-input" id="customFileLang" lang="es">
<label class="custom-file-label" for="customFileLang" data-browse="Buscar en disco"> </label>
<br><br><br>
<label for="imagen5">Ingrese imagen</label>
<input type="file" name="imagen5"  class="custom-file-input" id="customFileLang" lang="es">
<label class="custom-file-label" for="customFileLang" data-browse="Buscar en disco"> </label>
                </div>
                <br><br>
                <button class="btn btn-dark mr-3" style="background: whitesmoke">Agregar Venta</button>
                <button> <a href="/adminVentas" style="text-decoration: none; color:black; background: whitesmoke">Volver al panel de Ventas</a></button>
            </form>
            <br><br>
        </div>
    </div>



        </div>
        </div>
    </div>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH C:\Users\moons\OneDrive\Escritorio\arreglo\lorenzoprop\resources\views/agregarVenta.blade.php ENDPATH**/ ?>