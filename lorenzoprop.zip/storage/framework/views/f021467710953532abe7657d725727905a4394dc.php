
<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
    <h1>Modificar una Venta</h1>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="modificar">

            <form action="/modificarVenta" method="post" enctype="multipart/form-data" >
                <?php echo csrf_field(); ?>
                <?php echo method_field('put'); ?>
                <label> Dirección: </label>
               <br>
                <input type="text" name="dirección"
                       value="<?php echo e(old('dirección', $Compra->dirección)); ?>"
                       class="form-control">
                <br><br>
                <label>Precio: </label>
           <br>
                <input type="text" name="precio"
                       value="<?php echo e(old('precio', $Compra->precio)); ?>"
                       class="form-control">
                <br><br>
                <label>Descripción: </label>
                <br>
                <input type="text" name="descripción"
                       value="<?php echo e(old('descripción', $Compra->descripción)); ?>"
                       class="form-control">
                <br><br>

                <label>Imagen actual 1:</label> <br>
                <img src="/compras/<?php echo e($Compra->imagen); ?>" class="img-thumbnail my-2"><br>
                <label>  Imagen nueva (opcional):</label><br>
                <div class="custom-file mt-1 mb-4">
                    <input type="file" name="imagen"  class="custom-file-input" id="customFileLang" lang="es">
                    <label class="custom-file-label" for="customFileLang" data-browse="Buscar en disco"> </label>         </div>
                    <br><br>     <br>

                    <label>Imagen actual 2:</label><br>
                <img src="/compras/<?php echo e($Compra->imagen2); ?>" class="img-thumbnail my-2" ><br> 
                <label>  Imagen nueva (opcional):</label><br>
                <div class="custom-file mt-1 mb-4">
                    <input type="file" name="imagen2"  class="custom-file-input" id="customFileLang" lang="es">
                    <label class="custom-file-label" for="customFileLang" data-browse="Buscar en disco"> </label>         </div>
                    <br><br>

                    <label>Imagen actual 3:</label> <br>
                <img src="/compras/<?php echo e($Compra->imagen3); ?>" class="img-thumbnail my-2"><br>
                <label>  Imagen nueva (opcional):</label><br>
                <div class="custom-file mt-1 mb-4">
                    <input type="file" name="imagen3"  class="custom-file-input" id="customFileLang" lang="es">
                    <label class="custom-file-label" for="customFileLang" data-browse="Buscar en disco"></label>         </div>
                    <br><br>

                    <label>Imagen actual 4:</label> <br>
                <img src="/compras/<?php echo e($Compra->imagen4); ?>" class="img-thumbnail my-2" > <br>
                <label>  Imagen nueva (opcional):</label> <br>
                <div class="custom-file mt-1 mb-4">
                    <input type="file" name="imagen4"  class="custom-file-input" id="customFileLang" lang="es">
                    <label class="custom-file-label" for="customFileLang" data-browse="Buscar en disco"> </label>         </div>
                    <br><br>

                    <label>Imagen actual 5:</label><br>
                <img src="/compras/<?php echo e($Compra->imagen5); ?>" class="img-thumbnail my-2"><br>
                <label>  Imagen nueva (opcional):</label><br>
                <div class="custom-file mt-1 mb-4">
                    <input type="file" name="imagen5"  class="custom-file-input" id="customFileLang" lang="es">
                    <label class="custom-file-label" for="customFileLang" data-browse="Buscar en disco"></label>         </div>
                    <br><br>
                </div>

              
                       <input type="hidden" name="id"
                       value="<?php echo e($Compra->id); ?>">
                <input type="hidden" name="ImagenAnterior"
                       value="<?php echo e($Compra->imagen); ?>">
                       <input type="hidden" name="ImagenAnterior2"
                       value="<?php echo e($Compra->imagen2); ?>">
                       <input type="hidden" name="ImagenAnterior3"
                       value="<?php echo e($Compra->imagen3); ?>">
                       <input type="hidden" name="ImagenAnterior4"
                       value="<?php echo e($Compra->imagen4); ?>">
                       <input type="hidden" name="ImagenAnterior5"
                       value="<?php echo e($Compra->imagen5); ?>">

                <br>
                <button class="btn btn-dark mb-3" style="margin-left:37%; background: whitesmoke; margin-right:10px">Modificar Venta</button>
                <button> <a href="/adminVentas" class="btn btn-outline-secondary mb-3" style="text-decoration: none; color:black; background: whitesmoke">
                Volver al panel de Ventas
                </a></button>
               
            </form>

        </div>

        <?php if( $errors->any() ): ?>
            <div class="alert alert-danger col-8 mx-auto p-2">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>


        </div>
        </div>
    </div>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH C:\Users\moons\OneDrive\Escritorio\arreglo\lorenzoprop\resources\views/modificarVenta.blade.php ENDPATH**/ ?>