<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="mostrar">
        <h1><?php echo e($Compra->dirección); ?></h1>
<br>
<div  class="modal"  id="img1">
<div class="imagenes">


<a href="#img5">&#60;</a>
    <img src="/compras/<?php echo e($Compra->imagen); ?>" >
    <a href="#img2">></a>
</div>
</div>
<div  class="modal" id="img2">
<div class="imagenes">
    <a href="#img1">&#60;</a>
   <img src="/compras/<?php echo e($Compra->imagen2); ?>">
    <a href="#img3">></a>
</div>
</div>

<div  class="modal" id="img3">
<div class="imagenes">
    <a href="#img2">&#60;</a>
   <img src="/compras/<?php echo e($Compra->imagen3); ?>" >
    <a href="#img4">></a>
</div>
</div>
<div  class="modal" id="img4">
<div class="imagenes">
    <a href="#img3">&#60;</a>
   <img src="/compras/<?php echo e($Compra->imagen4); ?>">
    <a href="#img5">></a>
</div>
</div>
<div  class="modal" id="img5">
<div class="imagenes">
    <a href="#img4">&#60;</a>
   <img src="/compras/<?php echo e($Compra->imagen5); ?>" >
    <a href="#img1">></a>
</div>
</div>
<br><br>
<p>us$ <?php echo e($Compra->precio); ?></p>
<p class="bajar"><?php echo e($Compra->descripción); ?></p>

</div>

        <?php if( $errors->any() ): ?>
            <div class="alert alert-danger col-8 mx-auto p-2">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\moons\OneDrive\Escritorio\arreglo\lorenzoprop\resources\views/mostrarVentas.blade.php ENDPATH**/ ?>