<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<h1 id="alquiler">Propiedades en Alquiler</h1>
<br>
<div class="row">

<?php $__currentLoopData = $rentas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $renta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<a href="./mostrarAlquiler/<?php echo e($renta->id); ?>&#img1">
                <div class="col">
                    <div class="card" >
                        <img src="/rentas/<?php echo e($renta->imagen); ?> ">
                            <br>
                            <p><?php echo e($renta->dirección); ?></p>
                            <br>
                            <p>$ <?php echo e($renta->precio); ?><br></p>
                       </div>
                    <br><br></a>
                </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<br><br>

</div><div class="social" >
    <ul>
        <li><a href="https://www.facebook.com/Lorenzo-Prop-103590901866065" target="_blank"  class="icon-facebook"></a></li><br>
        <li><a href="https://www.instagram.com/lorenzo.prop/?utm_medium=copy_link" target="_blank" class="icon-instagram"></a></li><br>
        <li><a href="https://api.whatsapp.com/send?phone=+5491150017070" target="_blank" class="icon-whatsapp"></a></li><br>
        <li><a href="mailto:info@lorenzoprop.com" class="icon-envelop"></a></li><br>
    </ul>
    </div>
    

<div class="paginador">
<?php echo e($rentas->links()); ?>

</div>

<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\moons\OneDrive\Escritorio\arreglo\lorenzoprop\resources\views//alquiler.blade.php ENDPATH**/ ?>