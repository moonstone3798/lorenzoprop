<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<h1 id="venta">Propiedades en Venta</h1>
<br>
<div class="row">



    <?php $__currentLoopData = $compras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $compra): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<a href="./mostrarVentas/<?php echo e($compra->id); ?>&#img1" >
                <div class="col" >
                    <div class="card">
                        <img src="/compras/<?php echo e($compra->imagen); ?> " >
                            <br>
                            <p><?php echo e($compra->dirección); ?></p>
                            <br>
                            <p>u$s <?php echo e($compra->precio); ?><br></p>
                       </div>
                    <br><br></a>
                </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<br><br>


</div><div class="social" >
    <ul>
        <li><a href="https://www.facebook.com/Lorenzo-Prop-103590901866065" target="_blank"  class="icon-facebook"></a></li><br>
        <li><a href="https://www.instagram.com/lorenzo.prop/?utm_medium=copy_link" target="_blank" class="icon-instagram"></a></li><br>
        <li><a href="https://api.whatsapp.com/send?phone=+5491150017070" target="_blank" class="icon-whatsapp"></a></li><br>
        <li><a href="mailto:info@lorenzoprop.com" class="icon-envelop"></a></li><br>
    </ul>
    </div>
    

<div class="paginador">
<?php echo e($compras->links()); ?>

</div>

<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\moons\OneDrive\Escritorio\arreglo\lorenzoprop\resources\views//ventas.blade.php ENDPATH**/ ?>