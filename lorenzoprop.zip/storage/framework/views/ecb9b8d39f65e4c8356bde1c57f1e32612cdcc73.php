
<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
    <h1 style="text-align:center">Eliminar Alquiler</h1>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="background:rgba(255, 255, 255, 0.329); width:100%">

       

            <div class="col">
                <img src="/rentas/<?php echo e($Renta->imagen); ?>" class="img-thumbnail" style="width:400px; height:350px; object-fit:cover; margin-left:33.5%">
            </div>
            <div class="col text-danger align-self-center">
            <form action="/eliminarAlquiler" method="post" style="text-align:center">
            <?php echo csrf_field(); ?>
            <?php echo method_field('delete'); ?>
                <h2><?php echo e($Renta->id); ?></h2>
                <br>
                <label>   dirección  <?php echo e($Renta->dirección); ?> </label>
                <br>
                <label> precio  $ <?php echo e($Renta->precio); ?></label>
                <br>
                <label> descripción  <?php echo e($Renta->descripción); ?></label>
                <br>
                  

                <input type="hidden" name="id"
                       value="<?php echo e($Renta->id); ?>">
                <input type="hidden" name="dirección"
                       value="<?php echo e($Renta->dirección); ?>">
                <button class="btn btn-danger btn-block my-3">Confirmar baja</button>
                <a href="/adminAlquileres" class="btn btn-outline-secondary btn-block">
                    Volver a panel
                </a>

            </form>
            </div>
        </form>

            <script>
                Swal.fire(
                    'Advertencia',
                    'Si pulsa el botón "Confirmar baja", se eliminará la propiedad seleccionada.',
                    'warning'
                )
            </script>

</div>
        </div>
    </div>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH C:\Users\moons\OneDrive\Escritorio\arreglo\lorenzoprop\resources\views/eliminarAlquiler.blade.php ENDPATH**/ ?>