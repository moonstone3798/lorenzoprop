<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        
<h1 style="text-align:center">Administrar Ventas</h1>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="background:rgba(255, 255, 255, 0.329); width:100%">
             
<br>
<?php if( session('mensaje') ): ?>
    <div class="alert alert-success">
        <?php echo e(session('mensaje')); ?>

    </div>
<?php endif; ?>

<table class="table table-borderless table-striped table-hover" >
    <thead>
        <tr>
            <th>Id</th>
            <th>Dirección</th>
            <th>Precio</th>
            <th>Descripción</th>
            <th>Imagen</th>
            <th>Imagen 2</th>
            <th>Imagen 3</th>
            <th>Imagen 4</th>
            <th>Imagen 5</th>
            <th colspan="2">
            <button style=" text-decoration:none;"> <a href="/agregarVenta"  style="text-decoration: none; color:black">
                    Agregar
                </a></button>
            </th>
        </tr>
    </thead>
    <tbody>
<?php $__currentLoopData = $compras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $compra): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($compra->id); ?></td>
            <td style="width:20px"><?php echo e($compra->dirección); ?></td>
            <td><?php echo e($compra->precio); ?></td>
            <td style="width:70px"><?php echo e($compra->descripción); ?></td>
            <td><img src="/compras/<?php echo e($compra->imagen); ?>" class="img-thumbnail" style="width: 150px ; height:120px; object-fit:cover"></td>
            <td><img src="/compras/<?php echo e($compra->imagen2); ?>" class="img-thumbnail" style="width: 150px; height:120px; object-fit:cover"></td>
            <td><img src="/compras/<?php echo e($compra->imagen3); ?>" class="img-thumbnail" style="width: 150px; height:120px; object-fit:cover"></td>
            <td><img src="/compras/<?php echo e($compra->imagen4); ?>" class="img-thumbnail" style="width: 150px; height:120px; object-fit:cover"></td>
            <td><img src="/compras/<?php echo e($compra->imagen5); ?>" class="img-thumbnail" style="width: 150px; height:120px; object-fit:cover"></td>
            <td>
                <button>
               <a href="/modificarVenta/<?php echo e($compra->id); ?>"  style="text-decoration: none; color:black" >
                    Modificar
                </a></button>
            </td>
            <td>
                <button>
                 <a href="/eliminarVenta/<?php echo e($compra->id); ?>"  style="text-decoration: none; color:black">
                    Eliminar
                </a></button>
            </td>
        </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<br><br>
<div class="d-flex justify-content-center">

    <?php echo e($compras->links()); ?>

</div>

  
</div>
        </div>
    </div>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH C:\Users\moons\OneDrive\Escritorio\arreglo\lorenzoprop\resources\views/adminVentas.blade.php ENDPATH**/ ?>