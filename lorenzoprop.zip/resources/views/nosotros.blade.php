@include('layouts.header')
<main>
<div id="imagennosotros"><br><br><br> <br>
    <br>
    <h2>¿Quiénes somos?</h2><br><br><br><br><br></div>
    <div id="historia" >
    <h1>Nuestra historia</h1><br><br>
<p >En 1982 Norberto Rubén Lorenzo, oficial de policía, decide abrir N. Lorenzo Propiedades en uno de los barrios mas porteños de la ciudad, Monserrat.  </p><br>
<p>Luego de muchos años de clientes conformes decide volver al barrio que lo vio nacer, Boedo abriendo una sucursal que hoy sigue en pie manejada por Kytty Lorenzo también Corredora. Su compañera de toda la vida hoy es la cara visible y Martillera responsable de que los clientes obtengan la misma atención de siempre. </p><br>
<p>En un año de pandemia, 2021, donde muchos deciden cerrar, N. Lorenzo Propiedades hoy renombrado LORENZO PROP. tomo la iniciativa de abrir su nueva sucursal en Caballito. De la mano de Norberto Lorenzo hijo, haciéndolo sin miedo porque casi 40 años de transparencia lo respaldan. </p><br>
<p>Nuestro compromiso sigue intacto desde el primer día por brindar el mejor servicio a nuestros clientes… </p>
<br><br><br><br>
</div>
</div> 
<div class="social">
    <ul>
        <li><a href="https://www.facebook.com/Lorenzo-Prop-103590901866065" target="_blank"  class="icon-facebook"></a></li><br>
        <li><a href="https://www.instagram.com/lorenzo.prop/?utm_medium=copy_link" target="_blank" class="icon-instagram"></a></li><br>
        <li><a href="https://api.whatsapp.com/send?phone=+5491150017070" target="_blank" class="icon-whatsapp"></a></li><br>
        <li><a href="mailto:info@lorenzoprop.com" class="icon-envelop"></a></li><br>
    </ul>
    </div>   
    </main>
     @include('layouts.footer')